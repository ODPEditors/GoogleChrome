# DMOZ - Google Chrome

## Description

An extension for Google Chrome, displays a DMOZ search for the current site on a floating popup, and also allows to enter different search terms.

![Screenshot](https://dl.dropboxusercontent.com/u/9303546/ODP/EPT/GoogleChrome/screenshot.png)

## Installation

See: https://chrome.google.com/webstore/detail/dmoz/ohmpiokcbapdokaafenlahhelneekhea

## Source-code

https://github.com/ODPEditors/GoogleChrome

## Forum Thread

http://forums.dmoz.org/forum/viewtopic.php?t=xxx